var pub = {
	init: function(){
		this.setHeader();
		this.setFooter();
	},
	setHeader: function(){	},
	setFooter: function(){	}
}
$(function(){
	pub.init();
});
